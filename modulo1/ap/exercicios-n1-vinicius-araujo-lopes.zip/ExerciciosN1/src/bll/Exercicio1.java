/*
 * ---------------------------------------------------------------------------------------
 * Licença   : MIT - Copyright 2019 Viniciusalopes (Vovolinux) <suporte@vovolinux.com.br>
 * Criado em : 17/09/2019
 * Projeto   : ExerciciosN1
 * Finalidade: N1
 * ---------------------------------------------------------------------------------------
 */
package bll;

/**
 * 1. Escreva um programa que imprima a seguinte mensagem: “É preciso fazer
 * todos exercícios para aprender algoritmos!”.
 */
public class Exercicio1 {

    public static void main(String[] args) {
        vai();
    }

    public static void vai() {
        System.out.println();
        System.out.println("É preciso fazer todos exercícios para aprender algoritmos!");
    }
}
