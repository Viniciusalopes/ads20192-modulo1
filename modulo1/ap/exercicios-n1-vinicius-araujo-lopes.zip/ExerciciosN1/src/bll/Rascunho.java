/*
 * ---------------------------------------------------------------------------------------
 * Licença   : MIT - Copyright 2019 Viniciusalopes (Vovolinux) <suporte@vovolinux.com.br>
 * Criado em : 23/09/2019
 * Projeto   : ExerciciosN1
 * Finalidade: N1
 * ---------------------------------------------------------------------------------------
 */
package bll;

import bll.Exercicio1;
import bll.Exercicio2;

public class Rascunho {
    //import java.util.Scanner;

    public static void main(String[] args) {
        executa("1");
        executa("2");
    }
    
    public static void executa(String numero){
//        Class exercicio = new Class<"Exercicio" + numero >;
//        exercicio.metodo();
    }
}
