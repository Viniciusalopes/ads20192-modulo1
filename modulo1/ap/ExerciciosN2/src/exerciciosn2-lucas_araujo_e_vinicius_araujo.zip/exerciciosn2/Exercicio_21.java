/*
Faça um programa que leia o seu nome e o imprima 100 vezes.
 */

package exerciciosn2;
import java.util.Scanner;
public class Exercicio_21 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner (System.in);
         
        for (int n = 0; n <= 100; n++) {
            System.out.print("lucas-");
            System.out.println("|------araujo-|" );
            System.out.println("|------da silva----|");
            
        }
    }
}
