/*
 * ---------------------------------------------------------------------------------------
 * Licença   : MIT - Copyright 2019 Viniciusalopes (Vovolinux) <suporte@vovolinux.com.br>
 * Criado em : 23/10/2019
 * Projeto   : ExerciciosN2
 * Finalidade: N2
 * Alunos    : Lucas Araujo da Silva e Vinicius Araujo Lopes
 * ---------------------------------------------------------------------------------------
 */
package exerciciosn2;

import java.util.Scanner;

/**
 * 33. O IBOPE encomendou-lhe um programa para registrar as pesquisas das eleições entre
 * os candidatos 1, 2 e 3. Faça um programa que dado o candidato escolhido (1, 2 ou 3), a
 * idade e o sexo do eleitor(a) (1-mulher, 2-homem), para um número indeterminado de
 * eleitores, calcule e escreva: a) Qual o candidato mais votado b) Qual a média de idade
 * entre os eleitores do candidato mais votado c) Qual o candidato preferido dos homens
 */
public class ExercicioN2_33 {

    public static void main(String[] args) {
        // Declaração de variáveis
        Scanner sc;

        // Inicialização de variáveis
        sc = new Scanner(System.in);

        
    }

  
}
