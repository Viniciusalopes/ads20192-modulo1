/*
 22. Faça um programa que leia um número e imprima todos os números de 0 até o número
 digitado.
 */
package exerciciosn2;

/*
 for
 */
import java.util.Scanner;

public class Exercicio_22 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int numero = 0 , numeroinicoal = 0 , i ;
        System.out.print(" digite o numero ");
        numero = entrada.nextInt();
        for ( i = 0; i <= numero; i++) {
            System.out.println(i);
            
        }
            }
        }
    

        