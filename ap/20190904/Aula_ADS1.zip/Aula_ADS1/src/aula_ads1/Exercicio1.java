
/*
 * Licença   : MIT - Copyright 2019 Viniciusalopes (Vovolinux) <suporte@vovolinux.com.br>
 * Criado em : 11/09/2019
 * Projeto   : Aula_ADS1: Atividade 1 - Exercícios de Introdução
 * Finalidade: 1. Faça um programa que exiba a seguinte mensagem: "Este é meu primeiro programa!".
 */
package aula_ads1;

public class Exercicio1 {

    public static void main(String[] args) {
        agora_vai();
    }

    public static void agora_vai() {
        // Saída
        System.out.println("Este é o meu primeiro programa!");
    }
}
