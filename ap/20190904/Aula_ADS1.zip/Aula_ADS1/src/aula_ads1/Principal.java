/*
 * Licença   : MIT - Copyright 2019 Viniciusalopes (Vovolinux) <suporte@vovolinux.com.br>
 * Criado em : 11/09/2019
 * Projeto   : Aula_ADS1: Atividade 1 - Exercícios de Introdução
 * Finalidade: Exibir um menu com todos os exercícios da lista, seus enunciados e executar os exercícios.
 */
package aula_ads1;

import bll.Bll;

public class Principal {

    public static void main(String[] args) {
        // Exibe o menu principal
        Bll.menu();
    }
}
